package com.example.demo;


public class Post {
    private String value;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    // Altres camps i mètodes si n'hi ha
}