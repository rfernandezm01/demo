package com.example.demo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ApiService {

    @Value("${api.url}")
    private String apiUrl;

    private final RestTemplate restTemplate;

    public ApiService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getPost() {
        // Utilitza l'URL configurada en lugar de l'URL fixa
        return restTemplate.getForObject(apiUrl, String.class);
    }
}