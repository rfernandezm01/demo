package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class MyController {

    @Autowired
    private ApiService apiService;

    @GetMapping("/posts")
    public String getPosts(Model model) {
        String posts = apiService.getPost(); // Corregeix el mètode utilitzat aquí
        model.addAttribute("posts", posts);
        return "posts";
    }
}